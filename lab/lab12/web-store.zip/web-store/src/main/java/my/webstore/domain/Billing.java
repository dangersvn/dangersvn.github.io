package my.webstore.domain;

import java.time.LocalDateTime;

public class Billing {

    private User customer;
    private ShoppingCart cart;
    private long subtotal; // total items prices in a cart
    private long tax;
    private long discount;
    private long other;
    private long total;

    private String note;
    private LocalDateTime invoiceDate;


}
