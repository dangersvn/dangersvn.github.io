package my.webstore.controller;

import my.webstore.domain.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

import static my.webstore.security.SecurityUtil.USER;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // return cart.jsp
        HttpSession session = req.getSession();
        User user = (User)session.getAttribute(USER);
        req.setAttribute("carts", user.getCart().getCartItems());
        req.getRequestDispatcher("/WEB-INF/views/cart.jsp")
                .forward(req,resp);

    }
}
