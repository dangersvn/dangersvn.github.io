package my.webstore.service;

public class WebStoreFacadeFactory {
    private static WebStoreFacade facade;

    public static WebStoreFacade getWebStoreFacade() {
         if(facade == null) facade = new WebStoreFacadeImpl();
         return facade;
    }

}
