package my.webstore.repository;

public class WebStoreFactory {
    private static WebStoreRepository repository;

    public static WebStoreRepository getWebStoreRepository() {
         if(repository == null) repository = new WebStoreRepositoryImpl();
         return repository;
    }

}
