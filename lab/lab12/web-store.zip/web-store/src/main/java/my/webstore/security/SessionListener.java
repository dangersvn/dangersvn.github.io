package my.webstore.security;

import my.webstore.domain.User;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import static my.webstore.security.SecurityUtil.USER;

@WebListener
public class SessionListener implements HttpSessionListener {
    @Override
    public void sessionCreated(HttpSessionEvent se) {
        System.out.println("Session is created: " +  se);

        // assign guest user to session
        User user = new User();
        se.getSession().setAttribute(USER, user);
    }
}
