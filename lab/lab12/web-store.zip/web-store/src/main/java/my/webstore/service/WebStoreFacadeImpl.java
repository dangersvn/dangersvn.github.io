package my.webstore.service;

import my.webstore.domain.CartItem;
import my.webstore.domain.Product;
import my.webstore.domain.ShoppingCart;
import my.webstore.domain.User;
import my.webstore.repository.WebStoreFactory;
import my.webstore.repository.WebStoreRepository;

import java.util.List;

public class WebStoreFacadeImpl implements WebStoreFacade {

    WebStoreRepository repository = WebStoreFactory.getWebStoreRepository();

    @Override
    public List<Product> findAllProducts() {
        return repository.findAllProducts();
    }

    @Override
    public Product getProductByProductCode(String code) {
        return null;
    }

    @Override
    public User loginUser(String username, String password) {
        if(repository.findUserByUsername(username).isPresent()) {
            User user = repository.findUserByUsername(username).get();
            return user.getPassword().equals(password) ? user : null;
        }
        return null;
    }

    @Override
    public void registerUser(User user) {

    }

    @Override
    public void addProductToCart(User user, Product product) {
        ShoppingCart cart = user.getCart();
        cart.addToCart(product, 1);
    }

    @Override
    public void removeProductFromCart(User user, Product product) {

    }

    @Override
    public void viewCart(User user) {

    }

    @Override
    public List<CartItem> checkoutCart(User user) {
        List<CartItem> cartItems = user.getCart().getCartItems();
        user.getCart().clearCart();
        return cartItems;
    }
}
