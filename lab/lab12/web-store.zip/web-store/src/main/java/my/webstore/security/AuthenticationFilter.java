package my.webstore.security;

import my.webstore.domain.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebFilter(urlPatterns = {"/*"})
public class AuthenticationFilter implements Filter {
    private final ArrayList<String> AUTHENTICATED_URL = new ArrayList<>() {
        {
            add("/cart");
        }
    };

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        System.out.println("Enter Authentication filter");
        var req = ((HttpServletRequest) request);
        var res = ((HttpServletResponse) response);
        try {
            String currentLocation = req.getServletPath();
            if (!AUTHENTICATED_URL.contains(currentLocation)) {
                chain.doFilter(request, response);
            } else if (!((User)req.getSession().getAttribute(SecurityUtil.USER)).getGuest() ) {
                chain.doFilter(request, response);
            } else {
                // redirect
                req.getRequestDispatcher("login")
                        .forward(request,response);
//                req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req,res);
            }
        } finally {
            System.out.println("Finally Authentication filter");
        }
    }

    @Override
    public void destroy() {
    }
}
