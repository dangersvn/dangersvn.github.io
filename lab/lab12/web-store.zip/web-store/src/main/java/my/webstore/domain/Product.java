package my.webstore.domain;

import java.util.UUID;

public class Product {
    private String code;
    private String name;
    private String description;
    private String[] images;
    private long price;

    public Product(String name, String description, String[] images, long price) {
        code = UUID.randomUUID().toString();
        this.name = name;
        this.description = description;
        this.images = images;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String[] getImages() {
        return images;
    }

    public void setImages(String[] images) {
        this.images = images;
    }

    public long getPrice() {
        return price;
    }

    public void setPrice(long price) {
        this.price = price;
    }

    public String getCode() {
        return code.toString();
    }
}
