package my.webstore.domain;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private List<CartItem> cartItems;

    private long totalPrice;

    private Shipping shipping;
    private Payment payment;
    private Billing billing;

    ShoppingCart() {
        cartItems = new ArrayList<>();
    }

    public void addToCart(Product product, int quantity) {
        CartItem item = new CartItem();
        item.setProduct(product);
        item.setQuantity(quantity);
        cartItems.add(item);
    }

    public int getSize() {
        return cartItems != null ? cartItems.size() : 0;
    }

    public List<CartItem> getCartItems() {
        return cartItems;
    }

    public void clearCart() {
        cartItems.clear();
    }
}
