package my.webstore.repository;

import my.webstore.domain.Product;
import my.webstore.domain.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class WebStoreRepositoryImpl implements  WebStoreRepository {
    private List<Product> productList ;
    private List<User> userList;

    public WebStoreRepositoryImpl() {
        productList = new ArrayList<>();
        userList = new ArrayList<>();
        setupProducts();
        setupUsers();
    }
    private void setupUsers() {
        User user = new User();
        user.setUsername("admin");
        user.setPassword("123456");
        user.setGuest(false);
        userList.add(user);
    }
    private void setupProducts() {
        Product p = new Product("Sample product 1 ", "Very good product",null,300);
        productList.add(p);

        p = new Product("Sample product 2", "Very good product",null,400);
        productList.add(p);

        p = new Product("Sample product 3" , "Very good product",null,500);
        productList.add(p);

        p = new Product("Sample product 4", "Very good product",null,600);
        productList.add(p);

        p = new Product("Sample product 5", "Very good product",null,700);
        productList.add(p);

    }

    @Override
    public List<Product> findAllProducts() {
        return this.productList;
    }

    @Override
    public Product getProductByProductCode(String code) {
        return null;
    }


    @Override
    public Optional<User> findUserByUsername(String username) {
        return userList.stream().filter(user -> user.getUsername().equals(username)).findFirst();
    }

    @Override
    public void registerUser(User user) {
    }
}
