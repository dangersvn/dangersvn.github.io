package my.webstore.security;

public class SecurityUtil {
    public static String USER = "user";

}
