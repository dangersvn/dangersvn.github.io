package my.webstore.controller;

import my.webstore.domain.User;
import my.webstore.service.WebStoreFacade;
import my.webstore.service.WebStoreFacadeFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static my.webstore.security.SecurityUtil.USER;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    WebStoreFacade webStoreFacade;

    @Override
    public void init() throws ServletException {
        webStoreFacade = WebStoreFacadeFactory.getWebStoreFacade();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        var username = req.getParameter("username");
        var password = req.getParameter("password");

        User user = webStoreFacade.loginUser(username, password);
        if(user != null) {
            //user logged in
            req.getSession().setAttribute(USER, user);
            resp.sendRedirect("products");
        } else {
            // failed to login
            req.setAttribute("msg", "Wrong username or password");
            req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req,resp);
        }
    }
}
