package my.webstore.controller;

import com.google.gson.Gson;
import my.webstore.domain.Product;
import my.webstore.domain.ShoppingCart;
import my.webstore.domain.User;
import my.webstore.service.WebStoreFacade;
import my.webstore.service.WebStoreFacadeFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;

import static my.webstore.security.SecurityUtil.USER;

@WebServlet("/add-to-cart")
public class AddToCartServlet extends HttpServlet {
    private WebStoreFacade webStoreFacade;
    private Gson mapper;

    @Override
    public void init() throws ServletException {
        mapper = new Gson();
        webStoreFacade = WebStoreFacadeFactory.getWebStoreFacade();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = req.getReader();
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } finally {
            reader.close();
        }

        var json = sb.toString();
        Product product = mapper.fromJson(json, Product.class);

        User user = (User)req.getSession().getAttribute(USER);
        webStoreFacade.addProductToCart(user, product);
//        Object cart = session.getAttribute("cart");
//        if(cart == null) {
//            cart = new ShoppingCart();
//            session.setAttribute("cart", cart);
//        }
//        out.print(mapper.toJson(product));
    }

}
