package my.webstore.service;

import my.webstore.domain.*;

import java.util.List;

public interface WebStoreFacade {

    List<Product> findAllProducts();
    Product getProductByProductCode(String code);

    User loginUser(String username, String password);

    void registerUser(User user);

    void addProductToCart(User user, Product product);

    void removeProductFromCart(User user, Product product);

    void viewCart(User user);

    List<CartItem> checkoutCart(User user);
}
