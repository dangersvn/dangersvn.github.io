package my.webstore.domain;

public class Shipping {

    private User customer;
    private String address; // optional, default use the address from customer.
    private long fee;



}
