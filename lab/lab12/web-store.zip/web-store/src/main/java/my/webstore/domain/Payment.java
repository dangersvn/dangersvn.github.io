package my.webstore.domain;

public class Payment {
    private String name;
}
