package my.webstore.controller;

import com.google.gson.Gson;
import my.webstore.domain.Product;
import my.webstore.domain.ShoppingCart;
import my.webstore.domain.User;
import my.webstore.service.WebStoreFacade;
import my.webstore.service.WebStoreFacadeFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;

import static my.webstore.security.SecurityUtil.USER;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {
    private WebStoreFacade webStoreFacade;
    private Gson mapper;

    @Override
    public void init() throws ServletException {
        mapper = new Gson();
        webStoreFacade = WebStoreFacadeFactory.getWebStoreFacade();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        User user = (User)req.getSession().getAttribute(USER);
        var cartItems = webStoreFacade.checkoutCart(user);
        req.setAttribute("carts", cartItems);

        var dispatcher = req.getRequestDispatcher("/WEB-INF/views/checkout-confirmation.jsp");
        dispatcher.forward(req,resp);
    }
}
