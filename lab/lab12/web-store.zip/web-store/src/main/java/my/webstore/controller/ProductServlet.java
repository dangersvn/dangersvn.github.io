package my.webstore.controller;

import my.webstore.domain.ShoppingCart;
import my.webstore.domain.User;
import my.webstore.service.WebStoreFacade;
import my.webstore.service.WebStoreFacadeFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

import static my.webstore.security.SecurityUtil.USER;

//@WebServlet("/products")
@WebServlet(urlPatterns = {"", "/products"})
public class ProductServlet extends HttpServlet {
    WebStoreFacade webStoreFacade = WebStoreFacadeFactory.getWebStoreFacade();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        req.setAttribute("productList", webStoreFacade.findAllProducts());
        req.setAttribute("cartSize", getCartSize(session));

        var dispatcher = req.getRequestDispatcher("/WEB-INF/views/products.jsp");
        dispatcher.forward(req,resp);
    }

    private int getCartSize(HttpSession session) {
        if(session!=null) {
            User user = (User)session.getAttribute(USER);
            ShoppingCart cart = user.getCart();
            return cart.getSize();
        }
        return 0;
    }
}
