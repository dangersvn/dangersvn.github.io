package my.webstore.repository;

import my.webstore.domain.Product;
import my.webstore.domain.User;

import java.util.List;
import java.util.Optional;

public interface WebStoreRepository {

    List<Product> findAllProducts();

    Product getProductByProductCode(String code);

    Optional<User> findUserByUsername(String username);

    void registerUser(User user);
}
