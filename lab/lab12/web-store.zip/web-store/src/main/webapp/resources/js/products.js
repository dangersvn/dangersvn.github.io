var productModule = (function(){
    window.onload = () => {
        //Javascript handling for Product page
        let addToCarts = document.querySelectorAll(".product .add-cart");
        addToCarts.forEach(btn => btn.onclick = addToCart);
    }

    function addToCart(evt) {
        let code = evt.target.dataset.productCode;
        let product = {code: code};
        fetch('add-to-cart', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(product),
        })
            // .then(response => response.json())
            .then(data => processData(data))
            .catch((error) => {
                console.error('Error:', error);
            });
    }

    function processData(data) {
        let currentSize = +document.getElementById("cart-size").innerText;
        document.getElementById("cart-size").innerText = ++currentSize
    }

})();

