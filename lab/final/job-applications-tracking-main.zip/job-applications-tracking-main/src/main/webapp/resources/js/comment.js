const commentModule = (function () {
    let commentTextarea;
    let activities;
    window.onload = function () {
        activities = document.querySelector("div.comments");
        commentTextarea = document.getElementById("commentTextarea");
    }

    function saveComment(jobApplicationId) {
        addComment(jobApplicationId, commentTextarea.value);
    }

    async function addComment(applicationId, cmt) {
        if(cmt.trim().length === 0) return;
        let comment = {content: cmt};
        let url = `application/${applicationId}/comment`;
        await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(comment),
        })
            .then(response => response.json())
            .then(appendComment)
            .catch(alert);
    }

    function appendComment(comment) {

        let cmtElement = htmlCommentElement(comment);
        activities.insertAdjacentHTML("afterbegin", cmtElement);
        commentTextarea.value = "";
    }

    function htmlCommentElement(comment) {
        const {userName, content} = comment;
        const momentAgo = getMomentAgo(comment);
        return `<div class="comment-box">
                                    <img alt="avatar" src="/jobtracking/resources/images/avatar.png">
                                    <div class="message">
                                        <div><span class="username">${userName}</span> <span class="moment">${momentAgo}</span></div>
                                        <span class="box-content">${content}</span> 
                                    </div>
                                </div>`
    }

    function getComments(applicationId) {
        let url = `application/${applicationId}/comment`;
        return fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        })
            .then(response => response.json())
            .catch(ex => alert("Can't getComments: ", ex));
    }

    async function displayComments(applicationId) {
        const {userName, comments} = await getComments(applicationId);
        if (activities && comments) {
            removeAllChildNodes(activities);
            let momentAgo;
            for (let comment of comments) {
                comment.userName = userName;
                momentAgo = getMomentAgo(comment);
                activities.insertAdjacentHTML("afterbegin", htmlCommentElement(comment));
            }
        }
    }

    function getMomentAgo(comment) {
        const {year, month, day} = comment.createdDate.date;
        const {hour, minute, second} = comment.createdDate.time;
        const stringDate = `${year}-${month}-${day} ${hour}:${minute}:${second}`;
        return moment(stringDate).fromNow();
    }

    function removeAllChildNodes(parent) {
        while (parent.firstChild) {
            parent.removeChild(parent.firstChild);
        }
    }

    return function (applicationId) {
        return {
            displayComments: () => displayComments(applicationId),
            saveComment: () => saveComment(applicationId)
        }
    }
})();

var CommentModule = commentModule;