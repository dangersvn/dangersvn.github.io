"use strict"
import {JATApplication} from "../jat.js";

if (window.addEventListener) // W3C standard
{
    window.addEventListener('load', function () {
        setInterval(updateUserInfo,3000);
        function updateUserInfo(){
            let url = "userinfo";
            return fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                }
            })
                .then(response => response.json())
                .then(json=>document.getElementById("username").innerHTML = `Hello,${json.username} (<strong>${json.totalapp}</strong>)`)
                .catch(ex => console.log("Can't get user info: " + ex));
        }
        document.getElementById("create-dialog").style.display = "none";
        const selectTargetStatus = document.getElementById('targetStatus');
        // const detailNextAppointmentDate = document.getElementById('detailNextAppointmentDate');
        // detailNextAppointmentDate.min = new Date().toISOString();
        for (const statusKey in JATApplication.STATUS) {
            const opt = document.createElement('option');
            opt.value = JATApplication.STATUS[statusKey];
            opt.innerHTML = JATApplication.STATUS[statusKey];
            selectTargetStatus.appendChild(opt);
        }
        selectTargetStatus.onchange = function (e) {
            if (e.target.value === JATApplication.STATUS.CLOSED) {
                document.getElementById("next-appointment-date").disabled = true;
            } else {
                document.getElementById("next-appointment-date").disabled = false;
            }
        }
        document.getElementById('jat-cancel-button').onclick=function (){
            document.getElementById("create-dialog").style.display = "none";
        }
        document.getElementById('jat-create-button')
            .onclick = function (e) {
            //alert("hello" + this.form.innerHTML);
            //createApp: call ajax to submit the form and reflex the new job app in the client based on returning data
            JATApplication.createApp(this.form[0].value, this.form[1].value, this.form[2].value, this.form[3].value, this.form[4].value,
                (jatResponse) => {
                    let el = document.getElementById("block-" + jatResponse.status);
                    let jobapp = document.createElement("div");
                    jobapp.className = "app-content-box";
                    jobapp.dataset.jobApplicationId = jatResponse.id;
                    jobapp.innerHTML = `<p>Company: <br>&nbsp&nbsp<strong>${jatResponse.company}</strong><p>
                                            <p>Position: <br>&nbsp&nbsp<strong>${jatResponse.position}</strong><p>
                                            <p>Next Appointment: <br>&nbsp&nbsp<strong>${jatResponse.nextAppointment.date.month}-${jatResponse.nextAppointment.date.day}-${jatResponse.nextAppointment.date.year} ${jatResponse.nextAppointment.time.hour}:${jatResponse.nextAppointment.time.minute}</strong></p> 
                                                `;
                    el.append(jobapp);
                    jobapp.onclick = viewJobApplicationDetails; //add event so that it can be clicked to view/edit later
                    //console.log(jatResponse);
                    document.getElementById("create-dialog").style.display = "none";
                });
        };

        document.querySelectorAll('.header-right')
            .forEach(value => value.onclick = function (e) { //display Job App creation form
                const dialog = document.getElementById("create-dialog");
                dialog.querySelector("#targetStatus").value=this.dataset.status; //assign default value for status field
                dialog.style.display = "block";
                dialog.style.position = "fixed";
                dialog.style.left = ((e.clientX > window.screen.width)?e.clientX - (250):e.clientX) + "px";
                dialog.style.top = e.clientY + 20 + "px";
            });

        document.querySelector("a.close").onclick = () => detailsDialog.close();

        document.querySelectorAll(".app-content")
            .forEach(element => {element.onclick = viewJobApplicationDetails;});

        function viewJobApplicationDetails() {
            if (typeof detailsDialog.showModal === "function") {
                JATApplication.get(this.dataset.jobApplicationId, (jatApplication)=>{
                  detailsDialog.showModal();
                  detailsDialog.querySelector(".value-status").innerHTML = jatApplication.status;
                  detailsDialog.querySelector(".value-company").innerHTML = jatApplication.company;
                  detailsDialog.querySelector(".value-position").innerHTML = jatApplication.position;
                  detailsDialog.querySelector(".value-job-description").innerHTML = jatApplication.jobDescription;
                  const nextAppointment = new Date(jatApplication.nextAppointment.date.year,jatApplication.nextAppointment.date.month,jatApplication.nextAppointment.date.day,jatApplication.nextAppointment.time.hour,jatApplication.nextAppointment.time.minute);
                  detailsDialog.querySelector(".value-next-appointment").innerHTML = nextAppointment.toISOString();

                  document.getElementById('detailNextAppointmentDate').value = nextAppointment.toISOString().slice(0,16);

                  document.getElementById("change-status-dialog").querySelector("[name='id']").value = jatApplication.id;
                });
                const commentModule = new CommentModule(this.dataset.jobApplicationId);
                commentModule.displayComments();
                document.querySelector("#saveComment").onclick = commentModule.saveComment;
            } else {
                alert("The <dialog> API is not supported by this browser");
            }
        }
    }, false); // NB **not** 'onload'
}
