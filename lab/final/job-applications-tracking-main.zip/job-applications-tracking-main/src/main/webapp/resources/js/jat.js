"use strict"
const jatApp = (function () {
  // A private counter variable
  const jobApplications = [];

  const addJobApplication = function (jobApplication) {
    console.log(jobApplication);
  };

  return {
    STATUS: {
      "NEWLY": "NEWLY",
      "PHONE_SCREEN": "PHONE_SCREEN",
      "INTERVIEW": "INTERVIEW",
      "OFFER_LETTER": "OFFER_LETTER",
      "CLOSED": "CLOSED"
    },
    getAll: function () {
      return jobApplications;
    },
    add: function (jobApplication) {
      jobApplications.push(jobApplication);
    },
    changeStatus: function (id, targetStatus, nextAppointment, doSuccess) {
      fetch("./jat/change_status",
          {
            method: "POST",
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              "id": id,
              "targetStatus": targetStatus,
              "nextAppointment": nextAppointment
            })
          })
          .then(response => response.json())
          .then(data => doSuccess(data))
          .catch(alert);
    },
    createApp: function (company, position, jobDescription, status, nextAppointment, doSuccess) {
        fetch("jobappcreate",
            {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    "company": company,
                    "position": position,
                    "jobDescription": jobDescription,
                    "status": status,
                    "nextAppointment": nextAppointment
                })
            })
            .then(response => response.json())
            .then(data => doSuccess(data))
            .catch(alert);
    },
    get: function (id, onSuccess) {
      fetch("./jat/detail?id=" + id + "&view=json")
          .then(response => response.json())
          .then(onSuccess)
          .catch(alert);
    },
    applyDataChange(jatApplication) {
      const block = document.getElementById("block-jat-" + jatApplication.id)
          ? document.getElementById("block-jat-" + jatApplication.id)
          : document.getElementById('detailsDialog');
      const nextAppointment = new Date(jatApplication.nextAppointment.date.year,jatApplication.nextAppointment.date.month,jatApplication.nextAppointment.date.day,
          jatApplication.nextAppointment.time.hour,jatApplication.nextAppointment.time.minute);
      block.querySelector(".value-status").innerHTML = jatApplication.status;
      block.querySelector(".value-next-appointment").innerHTML = nextAppointment.toISOString();
    }
  };
})();

export const JATApplication = jatApp;
// JATApplication.get("FAKEID01");
// JATApplication.changeStatus("FAKEID01", JATApplication.STATUS.PHONE_SCREEN, "");