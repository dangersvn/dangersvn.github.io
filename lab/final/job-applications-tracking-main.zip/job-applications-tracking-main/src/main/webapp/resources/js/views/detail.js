"use strict"
import {JATApplication} from "../jat.js";

if (window.addEventListener) // W3C standard
{
  window.addEventListener('load', function () {
    const selectTargetStatus = document.getElementById('detailTargetStatus');
    // const detailNextAppointmentDate = document.getElementById('detailNextAppointmentDate');
    // detailNextAppointmentDate.min = new Date().toISOString();
    for (const statusKey in JATApplication.STATUS) {
      const opt = document.createElement('option');
      opt.value = JATApplication.STATUS[statusKey];
      opt.innerHTML = JATApplication.STATUS[statusKey];
      selectTargetStatus.appendChild(opt);
    }
    selectTargetStatus.onchange = function (e) {
      if (e.target.value === JATApplication.STATUS.CLOSED) {
        document.getElementById("detailNextAppointmentDate").disabled = true;
      } else {
        document.getElementById("detailNextAppointmentDate").disabled = false;
      }
    }

    document.getElementById('jat-change-status-button')
        .onclick = function (e) {
      JATApplication.changeStatus(this.form[0].value, this.form[1].value, this.form[2].value,
          (jatResponse) => {
            JATApplication.applyDataChange(jatResponse);
            document.getElementById("change-status-dialog").style.display = "none";
            document.getElementById("block-" + jatResponse.status)
                .appendChild(document.querySelector(".app-content[data-job-application-id='" + jatResponse.id + "']"));
          });
    };
    document.getElementById('jat-change-cancel-button')
        .onclick = function (e) {
      document.getElementById("change-status-dialog").style.display = "none";
    };

    document.querySelectorAll('.jat-status')
        .forEach(value => value.onclick = function (e) {
          const dialog = document.getElementById("change-status-dialog");
          dialog.style.display = "block";
          dialog.style.position = "fixed";
          dialog.style.left = e.clientX + "px";
          dialog.style.top = e.clientY + "px";
        });
  }, false); // NB **not** 'onload'
}
