package com.jat.controller;

import com.jat.dao.DAOFactory;
import com.jat.dao.JobApplicationService;
import com.jat.domain.JobApplication;
import com.jat.domain.Status;
import com.jat.domain.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.jat.security.AuthenticationFilter.USER;

@WebServlet("/jobapplist")
public class JobApplicationListController extends HttpServlet {
    private JobApplicationService jobApplicationService;

    @Override
    public void init() {
        jobApplicationService = DAOFactory.getJobApplicationService();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String nextJSP = "/WEB-INF/views/job-application/list.jsp";
        User user = (User)req.getSession().getAttribute(USER);
        List<JobApplication> jobApplicationList =jobApplicationService.getJobApplications(user);

        req.setAttribute("newlyApplications", jobApplicationList.stream()
                .filter(jobApplication -> jobApplication.getStatus().equals(Status.NEWLY))
                .collect(Collectors.toList()));
        req.setAttribute("phoneScreenApplications", jobApplicationList.stream()
                .filter(jobApplication -> jobApplication.getStatus().equals(Status.PHONE_SCREEN))
                .collect(Collectors.toList()));
        req.setAttribute("interviewApplications", jobApplicationList.stream()
                .filter(jobApplication -> jobApplication.getStatus().equals(Status.INTERVIEW))
                .collect(Collectors.toList()));
        req.setAttribute("offerLetterApplications", jobApplicationList.stream()
                .filter(jobApplication -> jobApplication.getStatus().equals(Status.OFFER_LETTER))
                .collect(Collectors.toList()));
        req.setAttribute("closedApplications", jobApplicationList.stream()
                .filter(jobApplication -> jobApplication.getStatus().equals(Status.CLOSED))
                .collect(Collectors.toList()));

        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
        dispatcher.forward(req,resp);
    }
}
