package com.jat.controller;

import com.jat.dao.DAOFactory;
import com.jat.domain.User;
import com.sun.tools.jconsole.JConsoleContext;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.jat.security.AuthenticationFilter.USER;

@WebServlet("/userinfo")
public class UserInfoController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = (User) req.getSession().getAttribute(USER);
        long totalJobApp = DAOFactory.getJobApplicationService().getCountJobApplications(user);
        resp.getWriter().write("{\"username\":\"" + user.getUsername() + "\", \"totalapp\":\"" + totalJobApp + "\"}");
    }
}
