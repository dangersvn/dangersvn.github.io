package com.jat.service;

import com.jat.dao.DAOFactory;
import com.jat.dao.UserDAO;
import com.jat.domain.Comment;
import com.jat.domain.JobApplication;
import com.jat.domain.User;

import java.util.List;

public class ApplicationTrackingFacadeImpl implements ApplicationTrackingFacade {
    UserDAO userDAO = DAOFactory.getUserDAO();

    @Override
    public User loginUser(String username, String password) {
        User user = userDAO.findByUserName(username).orElse(null);

        if(user != null) {
            return user.getPassword().equals(password) ? user : null;
        } else {
            return null;
        }
    }

    @Override
    public void registerUser(User user) throws Exception {
        if(userDAO.findByUserName(user.getUsername()).isPresent()) {
            throw new Exception("Username already existed!");
        }
        if(userDAO.findByEmail(user.getEmail()).isPresent()) {
            throw new Exception("Email already existed!");
        }
        userDAO.saveUser(user);
    }

    @Override
    public Comment addComment(JobApplication application, String comment) {
        return application.addComment(comment);
        // save to db
    }
}
