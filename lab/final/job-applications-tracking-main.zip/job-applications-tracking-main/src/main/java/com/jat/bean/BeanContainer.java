package com.jat.bean;

import com.google.gson.Gson;

public class BeanContainer {
    private static Gson mapper;

    public static Gson getGsonMapper() {
        if(mapper == null)
            mapper = new Gson();
        return mapper;

    }

}
