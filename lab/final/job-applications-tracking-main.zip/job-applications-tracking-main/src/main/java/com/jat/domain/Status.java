package com.jat.domain;

import java.util.Arrays;

public enum Status {
    NEWLY,
    PHONE_SCREEN,
    INTERVIEW,
    OFFER_LETTER,
    CLOSED;

    Status findByName(String statusName) {
        return Arrays.stream(values()).filter(status -> status.toString().equals(statusName)).findFirst().orElse(null);
    }
}
