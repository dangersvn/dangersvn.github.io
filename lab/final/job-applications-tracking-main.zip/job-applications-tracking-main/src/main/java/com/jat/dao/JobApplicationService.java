package com.jat.dao;

import com.jat.domain.JobApplication;
import com.jat.domain.Status;
import com.jat.domain.User;

import java.time.LocalDateTime;
import java.util.List;

public interface JobApplicationService {
    JobApplication findById(String id);

    JobApplication changeStatus(JobApplication jobApplication, Status targetStatus, LocalDateTime nextAppointment);

    List<JobApplication> getJobApplications(User user);
    long getCountJobApplications(User user);

    void saveJobApplication(JobApplication jobApplication);

}
