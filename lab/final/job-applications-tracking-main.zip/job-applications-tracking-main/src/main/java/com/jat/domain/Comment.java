package com.jat.domain;

import java.time.LocalDateTime;
import java.util.UUID;

public class Comment {
    private String id;
    private LocalDateTime createdDate;
    private String content;

    Comment(String cmt) {
        id = UUID.randomUUID().toString();
        content = cmt;
        createdDate = LocalDateTime.now();
    }

    public String getId() {
        return id;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
