package com.jat.controller;

import com.jat.domain.User;
import com.jat.service.ApplicationTrackingFacade;
import com.jat.service.ApplicationTrackingFactory;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.jat.security.AuthenticationFilter.USER;

@WebServlet(urlPatterns = {"", "/login"})
public class LoginServlet extends HttpServlet {

    private ApplicationTrackingFacade applicationTrackingFacade;

    @Override
    public void init() {
        applicationTrackingFacade = ApplicationTrackingFactory.getApplicationTrackingFacade();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/user/login.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        var username = req.getParameter("username");
        var password = req.getParameter("password");

        User user = applicationTrackingFacade.loginUser(username, password);

        if(user != null) {
            //user logged in
            req.getSession().setAttribute(USER, user);
            resp.sendRedirect("jobapplist");
        } else {
            // failed to login
            req.setAttribute("msg", "Wrong username or password");
            req.getRequestDispatcher("/WEB-INF/views/user/login.jsp").forward(req,resp);
        }
    }
}
