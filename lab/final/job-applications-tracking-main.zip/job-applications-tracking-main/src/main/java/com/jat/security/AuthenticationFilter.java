package com.jat.security;

import javax.servlet.FilterChain;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;

@WebFilter(urlPatterns = "/*")
public class AuthenticationFilter extends HttpFilter {

    public static String USER = "user";
    private static ArrayList<String> ALLOWED_URL = new ArrayList<>() {
        {
            add("/login");
            add("/logout");
            add("/register");
        }
    };

    @Override
    protected void doFilter(HttpServletRequest req, HttpServletResponse res, FilterChain chain) {
        var session = req.getSession();
        try {
            String currentLocation = req.getServletPath();
            if (ALLOWED_URL.contains(currentLocation) || currentLocation.contains("/resources")) {
                chain.doFilter(req, res);
            } else if (session.getAttribute(USER) != null) {
                chain.doFilter(req, res);
            } else {
                res.sendRedirect("login");
            }
        } catch (Exception ex) {
            System.out.println("Exception in filter" + ex.getMessage());
        }
    }
}
