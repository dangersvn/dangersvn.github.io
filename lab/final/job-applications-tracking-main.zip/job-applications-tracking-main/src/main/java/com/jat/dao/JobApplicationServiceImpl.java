package com.jat.dao;

import com.jat.domain.JobApplication;
import com.jat.domain.Status;
import com.jat.domain.User;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class JobApplicationServiceImpl implements JobApplicationService {
    private static List<JobApplication> allJobApplications = new ArrayList<>();

    static {
        User user = DAOFactory.getUserDAO().findByUserName("admin").get();
        JobApplication jobApplication = new JobApplication(user, "Google", "Fullstack developer", "Go Moment is looking for a new all-star Full-Stack Engineer to join our team!\n" +
                "\n" +
                "--\n" +
                "\n" +
                "Go Moment is bringing instant customer service to 40 million hotel guests using AI. We're backed by major investors including Google, and scaling fast.\n" +

                         "You can view their website at http://www.gomoment.com or find them on Twitter, Facebook, and LinkedIn",
                Status.NEWLY, LocalDateTime.now(), LocalDateTime.of(2021, 2, 15, 10, 30));
        jobApplication.setId("FAKEID01");
        jobApplication.addComment("I want this job");
        allJobApplications.add(jobApplication);

        jobApplication = new JobApplication(user,"Microsoft", "Senior webapp developer", "Go Moment is looking for a new all-star Full-Stack Engineer to join our team!\n" +
                "You can view their website at http://www.gomoment.com or find them on Twitter, Facebook, and LinkedIn",
                Status.PHONE_SCREEN, LocalDateTime.now(), LocalDateTime.of(2021, 2, 15, 10, 30));
        allJobApplications.add(jobApplication);

        jobApplication = new JobApplication(user,"Facebook", "Mobile developer", "Go Moment is looking for a new all-star Full-Stack Engineer to join our team!\n" +
                "You can view their website at http://www.gomoment.com or find them on Twitter, Facebook, and LinkedIn",
                Status.PHONE_SCREEN, LocalDateTime.now(), LocalDateTime.of(2021, 2, 15, 10, 30));
        allJobApplications.add(jobApplication);

        jobApplication = new JobApplication(user,"Netflix", "Java developer", "Go Moment is looking for a new all-star Full-Stack Engineer to join our team!\n" +
                "You can view their website at http://www.gomoment.com or find them on Twitter, Facebook, and LinkedIn",
                Status.INTERVIEW, LocalDateTime.now(), LocalDateTime.of(2021, 2, 15, 10, 30));
        allJobApplications.add(jobApplication);
    }

    @Override
    public JobApplication findById(String id) {
        return allJobApplications.stream()
                .filter(jobApplication -> jobApplication.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    @Override
    public JobApplication changeStatus(JobApplication jobApplication, Status targetStatus, LocalDateTime nextAppointment) {
        jobApplication.setStatus(targetStatus);
        jobApplication.setNextAppointment(nextAppointment);
        System.out.println(jobApplication);
        return jobApplication;
    }

    @Override
    public List<JobApplication> getJobApplications(User user) {
        List<JobApplication> apps = allJobApplications.stream()
                .filter(app -> app.getUser().getId().equals(user.getId()))
                .collect(Collectors.toList());
        return apps;
    }

    @Override
    public void saveJobApplication(JobApplication jobApplication) {
        allJobApplications.add(jobApplication);
    }

    @Override
    public long getCountJobApplications(User user) {
        return allJobApplications.stream()
                .filter(app -> app.getUser().getId().equals(user.getId()))
                .count();
    }
}
