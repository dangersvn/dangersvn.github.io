package com.jat.dao;

import com.jat.domain.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class UserDAOImpl implements UserDAO {
    private List<User> userList;
    public UserDAOImpl() {
        setupUsers();
    }

    private void setupUsers() {
        userList = new ArrayList<>();
        User user = new User("Admin", "admin", "123456", "admin@jat.com");
        userList.add(user);
    }

    @Override
    public Optional<User> findByUserName(String username) {
        return userList.stream().filter(u -> u.getUsername().equals(username)).findAny();
    }

    @Override
    public Optional<User> findByEmail(String email) {
        return userList.stream().filter(u -> u.getEmail().equals(email)).findAny();
    }

    @Override
    public void saveUser(User user) {
        int id = userList.indexOf(user);
        if(id < 0) {
            userList.add(user);
        } else {
            userList.set(id, user);
        }
    }
}
