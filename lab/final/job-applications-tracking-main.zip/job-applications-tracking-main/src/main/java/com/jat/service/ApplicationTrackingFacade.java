package com.jat.service;

import com.jat.domain.Comment;
import com.jat.domain.JobApplication;
import com.jat.domain.User;

public interface ApplicationTrackingFacade {

    User loginUser(String username, String password);

    void registerUser(User user) throws Exception;

    Comment addComment(JobApplication application, String comment);
}
