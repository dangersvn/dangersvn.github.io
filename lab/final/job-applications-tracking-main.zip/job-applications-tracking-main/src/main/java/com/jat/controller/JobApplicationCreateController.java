package com.jat.controller;

import com.google.gson.Gson;
import com.jat.dao.DAOFactory;
import com.jat.domain.JobApplication;
import com.jat.domain.Status;
import com.jat.domain.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Map;

import static com.jat.security.AuthenticationFilter.USER;

@WebServlet("/jobappcreate")
public class JobApplicationCreateController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = req.getReader();
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } finally {
            reader.close();
        }
        Gson mapper = new Gson();
        Map<String, String> data = mapper.fromJson(sb.toString(), Map.class);
        String strNextAppointmentDate = data.get("nextAppointment");
        LocalDateTime date = LocalDateTime.now();
        LocalDateTime today = LocalDateTime.parse(data.get("nextAppointment"));
        User user = (User)req.getSession().getAttribute(USER);
        JobApplication job = new JobApplication(user, data.get("company"),
                data.get("position"),
                data.get("jobDescription"),Status.valueOf(data.get("status")),date, today);
        DAOFactory.getJobApplicationService().saveJobApplication(job);
        resp.getWriter().println(mapper.toJson(job));
    }
}
