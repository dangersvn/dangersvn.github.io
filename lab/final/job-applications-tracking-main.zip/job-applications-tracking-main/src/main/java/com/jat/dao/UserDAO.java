package com.jat.dao;

import com.jat.domain.User;

import java.util.Optional;

public interface UserDAO {
    Optional<User> findByUserName(String username);

    Optional<User> findByEmail(String email);

    /**
     * Create new or update if username exist
     * @param user: user object
     */
    void saveUser(User user);
}
