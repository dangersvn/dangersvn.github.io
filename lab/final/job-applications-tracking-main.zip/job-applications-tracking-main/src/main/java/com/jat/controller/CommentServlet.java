package com.jat.controller;

import com.google.gson.Gson;
import com.jat.bean.BeanContainer;
import com.jat.dao.JobApplicationService;
import com.jat.dao.JobApplicationServiceImpl;
import com.jat.domain.Comment;
import com.jat.domain.JobApplication;
import com.jat.domain.User;
import com.jat.service.ApplicationTrackingFacade;
import com.jat.service.ApplicationTrackingFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import static com.jat.security.AuthenticationFilter.USER;

@WebServlet("/application/*")
public class CommentServlet extends HttpServlet {
    private ApplicationTrackingFacade applicationTrackingFacade;
    private JobApplicationService jobApplicationService;
    private Gson mapper = BeanContainer.getGsonMapper();

    @Override
    public void init() {
        applicationTrackingFacade = ApplicationTrackingFactory.getApplicationTrackingFacade();
        jobApplicationService = new JobApplicationServiceImpl();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User user = (User)req.getSession().getAttribute(USER);
        String[] pathParts = parsePathParams(req);
        if(pathParts.length < 2 || !"comment".equals(pathParts[2])) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
        String applicationId = pathParts[1]; // expected: application id
        JobApplication jobApplication = jobApplicationService.findById(applicationId);
        if(jobApplication.getUser().getId().equals(user.getId())) {
            ListCommentsDTO commentDTO = new ListCommentsDTO(user.getUsername(), jobApplication.getComments());
            resp.getWriter().print(mapper.toJson(commentDTO));
        } else {
            resp.sendError(HttpServletResponse.SC_UNAUTHORIZED);
        }
    }

    private String[] parsePathParams(HttpServletRequest req) {
        String pathInfo = req.getPathInfo(); // /{value}/test
        return pathInfo.split("/");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws  IOException {
        User user = (User)req.getSession().getAttribute(USER);

        String[] pathParts = parsePathParams(req);
        if(pathParts.length < 2 || !"comment".equals(pathParts[2])) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
        String applicationId = pathParts[1]; // expected: application id
        JobApplication jobApplication = jobApplicationService.findById(applicationId);
        if(jobApplication == null) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }

        String json = buildJsonString(req);
        Comment cmt = mapper.fromJson(json, Comment.class);
        cmt = applicationTrackingFacade.addComment(jobApplication, cmt.getContent());
        CommentDTO commentDTO = new CommentDTO(user.getName(), cmt.getCreatedDate(), cmt.getContent());
        resp.getWriter().print(mapper.toJson(commentDTO));
    }

    private String buildJsonString(HttpServletRequest req) throws IOException {
        StringBuilder sb = new StringBuilder();
        try(BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        }

        return sb.toString();
    }
    private class CommentDTO {
        private String userName;
        private LocalDateTime createdDate;
        private String content;

        public CommentDTO(String userName, LocalDateTime createdDate, String content) {
            this.userName = userName;
            this.createdDate = createdDate;
            this.content = content;
        }
    }
    private class ListCommentsDTO {
        private List<Comment> comments;
        private String userName;

        ListCommentsDTO(String username, List<Comment> commentList) {
            this.userName = username;
            this.comments = commentList;
        }
    }
}
