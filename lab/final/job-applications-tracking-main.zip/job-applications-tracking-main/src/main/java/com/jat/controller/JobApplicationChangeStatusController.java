package com.jat.controller;

import com.google.gson.Gson;
import com.jat.dao.JobApplicationService;
import com.jat.dao.JobApplicationServiceImpl;
import com.jat.domain.JobApplication;
import com.jat.domain.Status;
import com.jat.domain.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Map;

import static com.jat.security.AuthenticationFilter.USER;

@WebServlet(urlPatterns = {"/jat/change_status"})
public class JobApplicationChangeStatusController extends HttpServlet {
    JobApplicationService jobApplicationService;
    Gson mapper = new Gson();

    @Override
    public void init() throws ServletException {
        super.init();
        jobApplicationService = new JobApplicationServiceImpl();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        }
        Map<String, String> data = mapper.fromJson(sb.toString(), Map.class);
        JobApplication jobApplication = jobApplicationService.findById(data.get("id"));
        User user = (User) req.getSession().getAttribute(USER);
        if (!jobApplication.getUser().equals(user)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        String strNextAppointmentDate = data.get("nextAppointment");
        LocalDateTime localDateTime = null;
        try {
            localDateTime = LocalDateTime.parse(strNextAppointmentDate);
        } catch (Exception exception) {
        }
        jobApplication = jobApplicationService.changeStatus(jobApplication, Status.valueOf(data.get("targetStatus")), localDateTime);
        resp.getWriter().println(mapper.toJson(jobApplication));
    }
}
