package com.jat.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class JobApplication {
    private String id;
    private String company;
    private String position;
    private String jobDescription;
    private Status status;
    private LocalDateTime createdDate;
    private LocalDateTime nextAppointment;
    private List<Comment> comments;

    private transient User user;

    public JobApplication(User user, String company, String position, String jobDescription, Status status, LocalDateTime createdDate, LocalDateTime nextAppointment) {
        this.company = company;
        this.position = position;
        this.jobDescription = jobDescription;
        this.status = status;
        this.createdDate = createdDate;
        this.nextAppointment = nextAppointment;
        this.id = UUID.randomUUID().toString();
        this.comments = new ArrayList<>();
        this.user = user;
        user.addJobApplication(this);
    }

    public User getUser() {
        return user;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getNextAppointment() {
        return nextAppointment;
    }

    public void setNextAppointment(LocalDateTime nextAppointment) {
        this.nextAppointment = nextAppointment;
    }

    @Override
    public String toString() {
        return "JobApplication{" +
                "id='" + id + '\'' +
                ", company='" + company + '\'' +
                ", position='" + position + '\'' +
                ", status=" + status +
                ", nextAppointment=" + nextAppointment +
                '}';
    }

    /**
     * Get all comments of a job application
     * @return all comments of a job application
     */
    public List<Comment> getComments() {
        return comments;
    }

    /**
     * Add a comment to a job application
     * @param content is content of a comment
     */
    public Comment addComment(String content) {
        Comment c = new Comment(content);
        this.comments.add(c);
        return c;
    }
}
