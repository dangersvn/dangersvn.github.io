package com.jat.service;

public class ApplicationTrackingFactory {

    private static ApplicationTrackingFacade facade;

    public static ApplicationTrackingFacade getApplicationTrackingFacade() {
        if(facade == null) facade = new ApplicationTrackingFacadeImpl();
        return facade;
    }
}
