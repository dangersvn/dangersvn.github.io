package com.jat.controller;

import com.jat.domain.User;
import com.jat.service.ApplicationTrackingFacade;
import com.jat.service.ApplicationTrackingFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private ApplicationTrackingFacade applicationTrackingFacade;

    @Override
    public void init() {
        applicationTrackingFacade = ApplicationTrackingFactory.getApplicationTrackingFacade();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/user/registration.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        var username = req.getParameter("username");
        var password = req.getParameter("password");

        var name = req.getParameter("name");
        var email = req.getParameter("email");

        var user = new User(name, username, password, email);
        try {
            applicationTrackingFacade.registerUser(user);
            req.getRequestDispatcher("/WEB-INF/views/user/registration-confirmation.jsp").forward(req,resp);
        } catch (Exception e) {
            req.getSession().setAttribute("msg", e.getMessage());
            resp.sendRedirect("register");
        }
    }
}
