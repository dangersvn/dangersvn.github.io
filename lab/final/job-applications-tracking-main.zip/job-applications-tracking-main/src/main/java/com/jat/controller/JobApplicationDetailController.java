package com.jat.controller;

import com.google.gson.Gson;
import com.jat.dao.JobApplicationService;
import com.jat.dao.JobApplicationServiceImpl;
import com.jat.domain.JobApplication;
import com.jat.domain.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.jat.security.AuthenticationFilter.USER;

@WebServlet(urlPatterns = {"/jat/detail"})
public class JobApplicationDetailController extends HttpServlet {
    JobApplicationService jobApplicationService;
    Gson mapper = new Gson();

    @Override
    public void init() throws ServletException {
        super.init();
        jobApplicationService = new JobApplicationServiceImpl();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        String view = req.getParameter("view");
        JobApplication jobApplication = jobApplicationService.findById(id);
        if (jobApplication == null) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        User user = (User) req.getSession().getAttribute(USER);
        if (!jobApplication.getUser().equals(user)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        if (view != null && view.equals("json")) {
            resp.getWriter().println(mapper.toJson(jobApplication));
            return;
        }
        req.setAttribute("jobApplication", jobApplication);
        req.getRequestDispatcher("/WEB-INF/views/job-application/detail.jsp")
                .forward(req, resp);
    }
}
