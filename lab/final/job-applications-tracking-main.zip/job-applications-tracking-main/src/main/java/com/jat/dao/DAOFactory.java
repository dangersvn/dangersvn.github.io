package com.jat.dao;

public class DAOFactory {
    private static UserDAO userDAO;
    private static JobApplicationService jobApplicationService;
    public static UserDAO getUserDAO() {
        if(userDAO == null) {
            userDAO = new UserDAOImpl();
        }
        return userDAO;
    }

    public static JobApplicationService getJobApplicationService() {
        if(jobApplicationService == null) {
            jobApplicationService = new JobApplicationServiceImpl();
        }
        return jobApplicationService;
    }
}
