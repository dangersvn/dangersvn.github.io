package filter;

import my.example.UserService;
import my.example.util.SecurityUtil;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebFilter(urlPatterns = {"/*"})
public class AuthenticationFilter implements Filter {
    private final ArrayList<String> ALLOW_URS = new ArrayList<>() {
        {
            add("/login");
            add("/logout");
        }
    };

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        System.out.println("Enter Authentication filter");
        var req = ((HttpServletRequest) request);
        var res = ((HttpServletResponse) response);
        try {
            String currentLocation = req.getServletPath();
            if (ALLOW_URS.contains(currentLocation)) {
                chain.doFilter(request, response);
            } else if (req.getSession().getAttribute(SecurityUtil.LOGGED_IN_USER) != null) {
                chain.doFilter(request, response);
            } else {
                // redirect
                res.sendRedirect("login");
            }
        } finally {
            System.out.println("Finally Authentication filter");
        }
    }

    @Override
    public void destroy() {
    }
}
