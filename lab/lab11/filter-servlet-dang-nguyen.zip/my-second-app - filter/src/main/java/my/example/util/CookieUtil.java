package my.example.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

public class CookieUtil {

    public static Cookie getCookie(HttpServletRequest request, String name) {

        Cookie c[] = request.getCookies();
        if (c != null) {
            for (int i = 0; i < c.length; i++) {
                if (c[i].getName().equals(name)) {
                    return c[i];
                }
            }
        }

        return null;
    }

}
