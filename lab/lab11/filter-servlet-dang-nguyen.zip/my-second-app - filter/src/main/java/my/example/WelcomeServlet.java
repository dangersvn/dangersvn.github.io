package my.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/welcome")
public class WelcomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        var writer = resp.getWriter();
        User user = (User) req.getSession().getAttribute("logged-in-user");
        String username = user != null ? user.getUsername() : "null";
        writer.print("<html><head><title>$Title$</title></head>");
        writer.print("<body>" + "Welcome: " + username +

                "<a style=\"float: left;\" href=\"logout\">Logout</a>" +
                "<p><em>This page is displayed only when user already logged in</em></p>" +
                "</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
