package my.example;

import my.example.util.CookieUtil;
import my.example.util.SecurityUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    UserService userService = UserService.getInstance();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        var writer = resp.getWriter();
        var checkedRememberMe = "";
        var username = "";
        Cookie c1 = CookieUtil.getCookie(req, SecurityUtil.REMEMBER_ME);
        if( c1 != null) {
            checkedRememberMe = c1.getValue().equals("true") ? " checked " : "";
        }
        Cookie c2 = CookieUtil.getCookie(req, SecurityUtil.USER_NAME);
        if( c2 != null) {
            username = c2.getValue();
        }
        writer.print("<html>\n" +
                "        <head>\n" +
                "          <title>$Title$</title>\n" +
                "        </head>\n" +
                "        <body>\n" +
                "        <form method=\"POST\" action=\"login\">\n" +
                "          <div>\n" +
                "            <h1>Login page</h1>\n" +
                "            <label> User Name: <input type=\"text\" name=\"username\" value=\"" + username + "\"></label>\n" +
                "            <label> Password: <input type=\"text\" name=\"password\"></label>\n" +
                "            <label> Remember me: <input type=\"checkbox\" name=\"remember\" " + checkedRememberMe + "></label>\n" +
                "            <p><em>Username/password: admin/123456</em></p>\n" +
                "          </div>\n" +
                "          <button type=\"submit\">Login</button>\n" +
                "        </form>\n" +
                "        </body>\n" +
                "        </html>");

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        var username = req.getParameter("username");
        var password = req.getParameter("password");
        var remember = req.getParameter("remember");
        User loggedUser = new User(username, password);
        if(userService.getAllUsers().containsKey(username)
                && userService.getAllUsers().get(username).equals(password)) {
            //user logged in
            processRememberMe(req, resp, username, remember, loggedUser);
            resp.sendRedirect("welcome");
        } else {
            // failed to login
            resp.sendRedirect("login");
        }
    }

    private void processRememberMe(HttpServletRequest req, HttpServletResponse resp, String username, String remember, User loggedUser) {
        req.getSession().setAttribute(SecurityUtil.LOGGED_IN_USER, loggedUser);
        Cookie c1 = new Cookie (SecurityUtil.REMEMBER_ME,"true");
        Cookie c2 = new Cookie (SecurityUtil.USER_NAME, username);
        if("on".equals(remember)) {
            c1.setMaxAge(SecurityUtil.EXPIRED_TIME_REMEMBER_ME);
            c2.setMaxAge(SecurityUtil.EXPIRED_TIME_REMEMBER_ME);

        } else {
            c1.setMaxAge(0);
            c2.setMaxAge(0);
        }
        resp.addCookie(c1);
        resp.addCookie(c2);
    }
}
