package my.example;

import java.util.HashMap;
import java.util.Map;

public class UserService {
    private static UserService userService = new UserService();
    private UserService() {

    }
    public static UserService getInstance() {
        return userService;
    }

    public Map<String,String> getAllUsers() {
        var users = new HashMap<String,String>();
        users.put("admin", "123456");
        return users;
    }

}
