package my.example.util;

public class SecurityUtil {
    public static String LOGGED_IN_USER = "logged-in-user";
    public static String REMEMBER_ME = "remember_me";
    public static String USER_NAME = "user_name";
    public static int EXPIRED_TIME_REMEMBER_ME = 30 * 24 * 60 * 60;

}
