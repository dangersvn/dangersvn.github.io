package demo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;

@WebServlet("/support")
public class SupportServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("Enter POST support servlet");
        var supportEmail = this.getServletContext().getInitParameter("support-email");
        System.out.println("SupportEmail: " + supportEmail);

        // user information
        var userName = req.getParameter("name");
        var userEmailAddress = req.getParameter("emailAddress");
        System.out.println("UserName: " + userName);
        System.out.println("EmailAddress: " + userEmailAddress);

        // problem content
        var problem = req.getParameter("problem");
        var description = req.getParameter("description");
        var ticketId = UUID.randomUUID();
        System.out.println("Problem: " + problem);
        System.out.println("Description: " + description);
        System.out.println("TicketId: " + ticketId);

        // response
        var writer = resp.getWriter();
        writer.println("<html>");
        writer.println("<title>Confirmation page</title>");
        writer.println("<style>body {display: flex;justify-content: center;}p {border: 2px solid black;}</style>");
        writer.println("<body>");
        writer.write(String.format("<p>Thank you! [%s] for contacting us. You should receive reply from us with in 24 hrs in\n" +
                "    your email address [%s]. Let us know in our support email [%s] if\n" +
                "    you don't receive reply within 24 hrs. Please be sure to attach your reference\n" +
                "    [%s] in your email</p>", userName, userEmailAddress, supportEmail, ticketId));
        writer.println("</body></html>");


    }
}
